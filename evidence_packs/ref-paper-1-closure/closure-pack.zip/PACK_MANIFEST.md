# Evidence Pack - REF-PAPER-1 Closure
pipeline_run_id: ref-paper-1
created_at: 2026-06-06T04:25:16Z
files_count: 6

| path | role | sha256 |
|------|------|--------|
| BYPASS_CHECK_OUTPUT.txt | verification_output | ef25ddd2c78a019ce18b4a3cc9b04f6b7a92e085335f73526fa863885771f3fc |
| DOCTOR_OUTPUT.txt | verification_output | 8d50dc9640da7f0a22b6dbe976f594a5f33e206f8b29f94c7db71d1641894f36 |
| DRY_RUN_OUTPUT.txt | verification_output | 6448825808b0467fbfef8607721596e7daf99e83349eb4db52eaaae09fef7fdf |
| TEST_OUTPUT.txt | verification_output | 3e94cb1910525e752b245b9eeaa7d6d26deeff6eaaf1d4a7880725d09ba009e6 |
| pipelines/reference_paper_review.yaml | pipeline_definition | 52a581fc540a1fca64e3f58b1d2b860d0e74a65da342de94b45924868364d5fe |
| PACK_MANIFEST.md | pack_manifest | self_excluded |

manifest_valid: true
